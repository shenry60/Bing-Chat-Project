﻿using BingChat.Examples;

// await Examples.AskSimply();
await Examples.AskWithConversation();