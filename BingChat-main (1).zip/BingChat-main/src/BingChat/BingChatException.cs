﻿namespace BingChat;

public sealed class BingChatException : Exception
{
    public BingChatException(string message) : base(message)
    {
    }
}