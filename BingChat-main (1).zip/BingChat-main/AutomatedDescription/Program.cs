﻿using BingChat;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Drawing.Diagrams;
using DocumentFormat.OpenXml.Wordprocessing;
using Serilog;
using System.Text.RegularExpressions;

namespace AutomatedDescription
{
    internal class Program
    {
        static void Main(string[] args)
        {
            RunBing(args).Wait();
        }
        static async Task RunBing(string[] args)
        {
            var log = new LoggerConfiguration()
               .WriteTo.File("log.txt", rollingInterval: RollingInterval.Day)
               .WriteTo.Console()
               .CreateLogger();
            // LOG file will be in the BIN folder in the project directory tree with the EXE 

            log.Information("STARTING BING AI PRODUCT DESCRIPTION SYSTEM");

            string start_prompt = "give me a detailed product description for a";   // CAN EXPERIMENT WITH PROMPTS
            string second_prompt = "and how it is used.";

            string spreadsheetFilename = @".\..\..\..\SampleParts.xlsx";
            // Get the terms column number.
            int InputPartNumberColumn = 2;
            int InputManufacturerColumn = 3;
            // Open the spreadsheet.
            List<Product> Products = new List<Product>();
            // ADD HERE - READING MANUFACTURER AND PART NUMBER FROM SPREADSHEET
            using (var workbook = new XLWorkbook(spreadsheetFilename))
            {
                // Get the first worksheet.
                var worksheet = workbook.Worksheet(1);

                // Get the terms from the spreadsheet.
                for (int i = 2; i <= worksheet.LastRowUsed().RowNumber(); i++)
                {
                    Product inputproduct = new Product();
                    inputproduct.PartNumber = worksheet.Cell(i, InputPartNumberColumn).Value.ToString();
                    inputproduct.Manufacturer = worksheet.Cell(i, InputManufacturerColumn).Value.ToString();
                    if (!string.IsNullOrEmpty(inputproduct.Manufacturer) && !string.IsNullOrEmpty(inputproduct.PartNumber))
                    {
                        Products.Add(inputproduct);
                    }
                }
            }

            string OutputFilename = @".\..\..\..\OuputFile.xlsx";

            var OutputWorkbook = new XLWorkbook();
            var ws = OutputWorkbook.Worksheets.Add("Product Descriptions");
            OutputWorkbook.SaveAs(OutputFilename);

#if false
            // use for testing without spreadsheet
            descriptions.Add("Tectran 670-11SG");
            descriptions.Add("Tectran 670-41");
            descriptions.Add("Pollak  12-800EP");
            descriptions.Add("Alfa Tools BBN74505");
            descriptions.Add("Alfa Tools BB74301");
            descriptions.Add("Alfa Tools J150126B");
            descriptions.Add("Alfa Tools J160101B");
#endif
            // Construct the chat client
            var client = new BingChatClient(new BingChatClientOptions
            {
                // Tone used for conversation
                Tone = BingChatTone.Precise,
            });

            // Define column numbers for output file
            int PartNumberColumn = 1;
            int ManufacturerColumn = 2;
            int ErrorFlagColumn = 3;
            int CleanResponseColumn = 4;

            int request_number = 0;
            int row = 1;

            // fill in output file column headers
            ws.Cell(row, ManufacturerColumn).Value = "Manufacturer";
            ws.Cell(row, PartNumberColumn).Value = "PartNumber";
            ws.Cell(row, ErrorFlagColumn).Value = "ErrorFlag";
            ws.Cell(row, CleanResponseColumn).Value = "ProductDescription";


            row++;
            foreach (Product prod in Products)
            {
                try
                {
                    prod.Prompt = start_prompt + " " + prod.Manufacturer + " " + prod.PartNumber + " " + second_prompt; // = "give me a detailed product description for a Pollak 12-800EP and how it is used."
                    request_number++;
                    log.Information("Request_number: " + request_number.ToString());

                    log.Information("Requesting: " + prod.Prompt);
                    prod.RawResponse = await client.AskAsync(prod.Prompt);
                    log.Information("Unedited Answer: " + prod.RawResponse);
                    prod.CleanResponse = CleanupResponse(prod.RawResponse);  // remove text links, and question about more info, after last cite 
                                                                             // i wouldnt use try/catch in the cleanup routines because the output for the sheet could be compromised.
                                                                             // if there's an exeception it will be caught in this loop and an error stored in the sheet
                                                                             // review the log file to determine what the error is - or run with breakpoints when trying a large sample
                    log.Information("CLEAN Answer: " + prod.CleanResponse);

                    ws.Cell(row, ManufacturerColumn).Value = prod.Manufacturer;
                    ws.Cell(row, PartNumberColumn).Value = prod.PartNumber;
                    if (prod.RawResponse.Contains("I'm sorry"))
                    {
                        // didnt find the product, non-answer-answer 
                        ws.Cell(row, ErrorFlagColumn).Value = "ERROR: PRODUCT NOT FOUND";
                    }
                    else
                    {
                        // found product and provided answer 
                        ws.Cell(row, CleanResponseColumn).Value = prod.CleanResponse;
                    }
                    OutputWorkbook.Save(); // don't have to save after every one but since there's a delay in the loop why not

                    log.Information("** Waiting before next request");
                    Thread.Sleep(30 * 1000);    // DELAY TO AVOID API THROTTLING
                                                // ADD HERE - STORE THE RESPONSE AND OTHER COLUMNS IN NEW SPREADSHEET
                    row++;
                }
                catch (Exception ex)
                {
                    log.Error(ex.ToString());
                    // ADD HERE - STORE ERROR IN SPREADSHEET CELL
                }
            }
            // ADD HERE - GRACEFULLY CLOSE THE SPREADSHEETS
            log.Information("************ END BING AI PRODUCT DESCRIPTION SYSTEM ************");
        }
        public static string CleanupResponse(string input)
        {
            string return_value = RemoveLeadingResponseBoilerplate(input);
            return_value = ConcatenateAfterLastCite(return_value);
            return_value = RemoveCites(return_value);   // do last
            return return_value;
        }

        public static string RemoveLeadingResponseBoilerplate(string input)
        {
            string match_string = @"Generating answers for you...";
            string returnvalue = input;
            if (input.Contains(match_string))
            {
                int startposition = input.LastIndexOf(match_string) + match_string.Length;
                returnvalue = input.Substring(startposition, input.Length - startposition);
            }
            return returnvalue.Trim();
        }

        public static string ConcatenateAfterLastCite(string input)
        {
            string match_string = "Is there anything else"; // Is there anything else you would like to know about this product?
                                                            // response comes back different occassionally - 
                                                            // just match "Is there anything" to avoid issues
                                                            // I hope this information helps! 😊\n\n
                                                            // NOTE - NEED MORE WORK HERE TO FIND THE END OF THE ANSWER BECAUSE BING IS VARYING THE LAST BIT TO MAKE IT HARD FOR PEOPLE TO DO WHAT YOU WANT TO DO. 
                                                            // POSSIBLE COMBINATION OF THE \n\n with punctuation before. not sure if that will work across all responses

                                                            // can remove end at first https
            string returnvalue = input;
            if (input.Contains(match_string))
            {
                returnvalue = input.Substring(0, input.LastIndexOf(match_string));
            }
            return returnvalue;
        }

        public static string RemoveCites(string input)
        {
            string pattern = @"\[.*\]";    // test here: https://regex101.com/r/gI4qJ6/150
            Regex regexObj = new Regex(pattern);
            input = regexObj.Replace(input, "");    // replace with nothing
            return input;
        }
        public static string RemoveOddPunctuations(string input)
        {
            input = input.Replace("**", ""); // add more below as needed - The Tectran 670-11SG is a **Single Pole Plug/Socket Tailgate Connector** with a **spring guard** 
            // input = input.Replace("**", "");
            return input;
        }
    }
    public class Product
    {
        public string PartNumber { get; set; }
        public string Manufacturer { get; set; }
        public string Prompt { get; set; }
        public string RawResponse { get; set; }
        public string CleanResponse { get; set; }

    }
}